package pl.ersjabogow.tester

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var nations: JSONArray

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nations = JSONArray(assets.open("nations.json").bufferedReader().use { it.readText() })
        root = FrameLayout(this)
        setContentView(root)
        showMenu()
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun page(title: String): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(14), dp(18), dp(14))
        box.setBackgroundColor(Color.rgb(38, 30, 24))

        val titleView = TextView(this)
        titleView.text = title
        titleView.textSize = 24f
        titleView.setTextColor(Color.rgb(235, 210, 170))
        titleView.setPadding(0, 0, 0, dp(12))
        box.addView(titleView)

        return box
    }

    private fun show(view: View) {
        root.removeAllViews()
        root.addView(view)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.textSize = 16f
        b.setOnClickListener { action() }
        parent.addView(b)
    }

    private fun addText(parent: LinearLayout, text: String, size: Float = 14f) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = size
        tv.setTextColor(Color.rgb(235, 225, 205))
        tv.setPadding(0, dp(6), 0, dp(6))
        parent.addView(tv)
    }

    private fun showMenu() {
        val p = page("ERSJA BOGÓW - Tester 0.2")
        addText(p, "Pierwsza instalowalna wersja testowa\n16 Nacji • baza zasad • tester danych", 15f)
        addButton(p, "16 NACJI") { showNations() }
        addButton(p, "ZASADY I BALANS") { showRules() }
        addButton(p, "TESTER") { showTester() }
        addText(
            p,
            "\nTa wersja celowo jest lekka. Najpierw uruchamiamy APK na telefonie. " +
            "Mapę graficzną, Heroldów i pełną automatyzację dokładamy w kolejnych aktualizacjach.",
            13f
        )
        show(ScrollView(this).apply { addView(p) })
    }

    private fun backButton(parent: LinearLayout) {
        addButton(parent, "← MENU") { showMenu() }
    }

    private fun showNations() {
        val p = page("16 Nacji")
        backButton(p)

        for (i in 0 until nations.length()) {
            val n = nations.getJSONObject(i)
            val traits = n.getJSONArray("traits")
            val t1 = traits.getJSONObject(0)
            val t2 = traits.getJSONObject(1)

            addButton(
                p,
                "${i + 1}. ${n.getString("name")} • ${n.getString("herald")}"
            ) {
                val d = page(n.getString("name"))
                backButton(d)
                addText(d, "CECHA 1: ${t1.getString("name")}\n${t1.getString("text")}", 16f)
                addText(d, "CECHA 2: ${t2.getString("name")}\n${t2.getString("text")}", 16f)
                addText(
                    d,
                    "Jednostka wręcz: ${n.getString("melee")}\n" +
                    "Jednostka dystansowa: ${n.getString("ranged")}\n\n" +
                    "Herold: ${n.getString("herald")}\n" +
                    "Broń: ${n.getString("heraldWeapon")}\n" +
                    "Oficjalna wysokość figurki Herolda: 60 mm",
                    15f
                )
                show(ScrollView(this).apply { addView(d) })
            }
        }
        show(ScrollView(this).apply { addView(p) })
    }

    private fun showRules() {
        val p = page("Zasady i balans")
        backButton(p)
        addText(p, "WALKA\n1 figurka = 1 jednostka. Maks. 3 jednostki na heks.\n" +
            "Wręcz: Atak 2 / Obrona 2 / zasięg 1.\n" +
            "Dystans: Atak 2 / Obrona 1 / zasięg 2.\n" +
            "Progi strat: 1-2 = 1, 3-4 = 2, 5+ = 3. Brak automatycznego kontrataku.", 15f)
        addText(p, "RUCH\n3 PR na akcję. Akcja = ruch + jedna interakcja. Interakcja kończy ruch.", 15f)
        addText(p, "TEREN\nLas +1 Obrony, Wzgórza +1, Góry +2, Bagna -1 Ataku napastnika, rzeka -1 Ataku wręcz.", 15f)
        addText(p, "TRANSPORT\nWóz: 4 PR / 6 zasobów / limit 3.\nStatek: 5 PR / 8 miejsc / limit 3.\nTransportów nie można atakować.", 15f)
        addText(p, "PRODUKCJA\nPole, Tartak, Kamieniołom i Kopalnia produkują bazowo po 2 zasoby na rundę. Standardowy limit: 3 każdego rodzaju.", 15f)
        addText(p, "MAGAZYNY\nWioska 15 • Osada 25 • Miasto 40.", 15f)
        addText(p, "POPULACJA\nNeutralna Wioska +1, Osada +2, Miasto +3.\nProgi wielokrotne: 3 → 1 zasób, 6 → 2 zasoby, 9 → +1 Wiary.", 15f)
        addText(p, "WIARA\nTor 0-10. Neutralna Wioska +1, Osada +2, Miasto +3. Progi 3/6/9 będą powiązane z Inwokacjami.", 15f)
        addText(p, "WPŁYW\nI Znajomość: handel 3:1.\nII Zaufanie: handel + 1 wybrany zasób/rundę.\nIII Kontrola: pełne korzyści miejscowości.", 15f)
        show(ScrollView(this).apply { addView(p) })
    }

    private fun showTester() {
        val p = page("Tester 0.2")
        backButton(p)
        addText(
            p,
            "Tryb testowy uruchomiony.\n\n" +
            "W tej pierwszej kompilacji sprawdzamy przede wszystkim instalację, " +
            "działanie bazy 16 Nacji i wyświetlanie ustalonych zasad.\n\n" +
            "Następna aktualizacja doda interaktywną mapę heksową, ruch i walkę.",
            16f
        )
        show(ScrollView(this).apply { addView(p) })
    }
}
