# ERSJA BOGÓW – LITE 0.2
Lekka paczka do pierwszego zbudowania APK na telefonie.

Zawiera kod aplikacji, 16 Nacji, cechy, Heroldów jako dane tekstowe, zasady,
tester mapy/walki, stały package oraz klucz podpisu do przyszłych aktualizacji.
Ciężkie grafiki zostały pominięte tylko w tej pierwszej paczce.

GitHub Actions zbuduje APK automatycznie z pliku:
.github/workflows/build-apk.yml
