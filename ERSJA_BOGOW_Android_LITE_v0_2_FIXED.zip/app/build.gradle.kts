plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "pl.ersjabogow.tester"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.ersjabogow.tester"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    signingConfigs {
        create("prototype") {
            storeFile = file("../prototype-release.jks")
            storePassword = "ersja-prototype"
            keyAlias = "ersja"
            keyPassword = "ersja-prototype"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("prototype")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("prototype")
        }
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
