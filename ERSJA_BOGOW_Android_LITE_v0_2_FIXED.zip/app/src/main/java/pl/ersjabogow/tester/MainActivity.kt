package pl.ersjabogow.tester

import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

class MainActivity: AppCompatActivity() {
    private lateinit var root: FrameLayout
    private var nations = JSONArray()
    private var rules = JSONObject()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        nations = JSONArray(assets.open("nations.json").bufferedReader().readText())
        rules = JSONObject(assets.open("rules.json").bufferedReader().readText())
        root = FrameLayout(this)
        setContentView(root)
        showMenu()
    }

    private fun base(title:String): LinearLayout {
        val page=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(14),dp(18),dp(14))
            setBackgroundColor(Color.rgb(39,31,25))
        }
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        if(title!="ERSJA BOGÓW – Tester 0.2"){
            bar.addView(Button(this).apply{text="←";setOnClickListener{showMenu()}},LinearLayout.LayoutParams(dp(58),dp(48)))
        }
        bar.addView(TextView(this).apply{
            text=title;textSize=23f;setTextColor(Color.rgb(232,208,166));gravity=Gravity.CENTER_VERTICAL
        },LinearLayout.LayoutParams(0,dp(52),1f))
        page.addView(bar)
        return page
    }

    private fun show(view:View){root.removeAllViews();root.addView(view)}

    private fun showMenu(){
        val p=base("ERSJA BOGÓW – Tester 0.2")
        p.addView(TextView(this).apply{
            text="Pełna baza projektu • 16 Nacji • zapis zasad v0.2\nPrototyp do testów na Androidzie"
            textSize=14f;setTextColor(Color.LTGRAY);setPadding(0,0,0,dp(12))
        })
        fun b(t:String,act:()->Unit)=Button(this).apply{text=t;textSize=16f;setOnClickListener{act()}}
        p.addView(b("🎮 TESTER MAPY I WALKI"){showTester()})
        p.addView(b("🏛️ 16 NACJI"){showNations()})
        p.addView(b("📜 ZASADY I BALANS"){showRules()})
        p.addView(b("🗺️ MAPA KRAINY ROZDARTE"){showImage("map_parchment.png","Krainy Rozdarte – wersja pergaminowa")})
        p.addView(b("🎴 WZORZEC PLANSZETKI"){showImage("player_board_egypt.png","Wzorzec wielowarstwowej planszetki Nacji")})
        p.addView(TextView(this).apply{
            text="\nAKTUALIZACJE\nKażda kolejna wersja zachowuje package pl.ersjabogow.tester i ten sam podpis testowy. Nowszy APK można instalować na starszym jako aktualizację.\n\nWersja 0.2 nie ma jeszcze AI ani pełnej automatyzacji wszystkich kart – dane i mechaniki są już zapisane do dalszej rozbudowy."
            textSize=13f;setTextColor(Color.LTGRAY)
        })
        show(ScrollView(this).apply{addView(p)})
    }

    private fun showNations(){
        val p=base("16 Nacji")
        for(i in 0 until nations.length()){
            val n=nations.getJSONObject(i)
            p.addView(Button(this).apply{
                text="${i+1}. ${n.getString("name")}   •   Herold: ${n.getString("herald")}"
                setOnClickListener{showNation(i)}
            })
        }
        show(ScrollView(this).apply{addView(p)})
    }

    private fun showNation(i:Int){
        val n=nations.getJSONObject(i)
        val p=base(n.getString("name"))
        val tr=n.getJSONArray("traits")
        fun txt(s:String,sz:Float=15f)=TextView(this).apply{
            text=s;textSize=sz;setTextColor(Color.rgb(238,226,204));setPadding(0,dp(6),0,dp(6))
        }
        p.addView(txt("CECHA 1\n${tr.getJSONObject(0).getString("name")}\n${tr.getJSONObject(0).getString("text")}",17f))
        p.addView(txt("CECHA 2\n${tr.getJSONObject(1).getString("name")}\n${tr.getJSONObject(1).getString("text")}",17f))
        p.addView(txt("⚔️ Wręcz: ${n.getString("melee")}\n🏹 Dystans: ${n.getString("ranged")}\n\nHEROLD: ${n.getString("herald")} (${n.getString("heraldSex")})\nBroń: ${n.getString("heraldWeapon")}\nOficjalna wysokość: 60 mm"))
        val keys=listOf("herald_egypt.png","herald_rome.png","herald_greece.png","herald_vikings.png","herald_aztecs.png","herald_china.png","herald_japan.png","herald_celts.png","herald_persia.png","herald_babylon.png","herald_carthage.png","herald_sumer.png","herald_india.png","herald_inca.png","herald_korea.png","herald_huns.png")
        try {
            val bmp=BitmapFactory.decodeStream(assets.open(keys[i]))
            p.addView(ImageView(this).apply{setImageBitmap(bmp);adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_INSIDE})
        } catch(_:Exception){}
        show(ScrollView(this).apply{addView(p)})
    }

    private fun showRules(){
        val p=base("Zasady i balans")
        fun section(title:String, body:String){
            p.addView(TextView(this).apply{text=title;textSize=18f;setTextColor(Color.rgb(228,191,126));setPadding(0,dp(10),0,dp(3))})
            p.addView(TextView(this).apply{text=body;textSize=14f;setTextColor(Color.rgb(238,226,204))})
        }
        section("Walka","1 figurka = 1 jednostka • max 3/heks\nWręcz A2/O2/zasięg 1 • Dystans A2/O1/zasięg 2\nProgi strat: 1–2 = 1, 3–4 = 2, 5+ = 3\nBrak automatycznego kontrataku.\nLas +1 O, Wzgórza +1 O, Góry +2 O, Bagna −1 A napastnika, rzeka −1 A wręcz.")
        section("Ruch","3 PR na akcję. Równina 1, Las 2, Wzgórza 2, Góry 3, Bagna 3, Pustynia 2, Tundra 2, Śnieg/Lód 2, Skały 3, Wulkan 3, droga 1.\nAkcja = ruch + jedna interakcja; interakcja kończy ruch.")
        section("Transport","Wóz 4 PR / 6 zasobów / limit 3. Statek 5 PR / 8 miejsc / 1 jednostka = 2 miejsca / limit 3. Transportów nie można atakować.")
        section("Produkcja","Pole/Tartak/Kamieniołom/Kopalnia: po 2 zasoby/rundę. Limit standardowy 3 każdego rodzaju; Babilon 4.")
        section("Magazyny","Wioska 15 • Osada 25 • Miasto 40.")
        section("Populacja","Neutralna Wioska +1, Osada +2, Miasto +3. Progi wielokrotne: 3 → 1 dowolny zasób, 6 → 2 zasoby, 9 → +1 Wiary.")
        section("Wiara","Tor 0–10. Wioska +1, Osada +2, Miasto +3. Progi 3/6/9 będą wiązać się z Inwokacjami.")
        section("Wpływ","I Znajomość → handel 3:1. II Zaufanie → handel + 1 wybrany podstawowy zasób/rundę. III Kontrola → pełne korzyści miejscowości.")
        section("Potwory","Bestie i Potwory: małe proste karty. Legendarne Bestie: duże karty, własny ruch i zachowania. Pojawiają się z Wydarzeń i Zadań.")
        show(ScrollView(this).apply{addView(p)})
    }

    private fun showImage(asset:String,title:String){
        val p=base(title)
        try {
            val bmp=BitmapFactory.decodeStream(assets.open(asset))
            p.addView(ImageView(this).apply{setImageBitmap(bmp);adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_INSIDE})
        }catch(_:Exception){
            p.addView(TextView(this).apply{text="Grafika nie została dołączona do tej paczki.";setTextColor(Color.WHITE)})
        }
        show(ScrollView(this).apply{addView(p)})
    }

    private fun showTester(){
        val p=base("Tester mapy i walki")
        p.addView(BoardView(this),LinearLayout.LayoutParams(-1,dp(620)))
        p.addView(TextView(this).apply{
            text="Tester 0.2: kliknij własną jednostkę, potem heks. Wrogą grupę w zasięgu kliknij, aby wykonać grupowy atak. To moduł testowy – gospodarka, budowa i karty są zapisane w bazie zasad, ale ich automatyzację dodamy w kolejnych wersjach."
            textSize=13f;setTextColor(Color.LTGRAY)
        })
        show(ScrollView(this).apply{addView(p)})
    }

    private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
}

enum class Terrain(val move:Int,val def:Int,val color:Int){
    PLAINS(1,0,Color.rgb(190,180,120)),
    FOREST(2,1,Color.rgb(70,110,70)),
    HILLS(2,1,Color.rgb(145,125,80)),
    MOUNTAINS(3,2,Color.rgb(125,125,120)),
    SWAMP(3,0,Color.rgb(80,105,85)),
    DESERT(2,0,Color.rgb(215,180,110)),
    TUNDRA(2,0,Color.rgb(190,200,195)),
    VOLCANIC(3,0,Color.rgb(105,75,65))
}
enum class Kind { MELEE,RANGED }
data class Hx(val q:Int,val r:Int,val terrain:Terrain)
data class Tok(var q:Int,var r:Int,val player:Int,val kind:Kind)

class BoardView(ctx:MainActivity):View(ctx){
    private val R=38f; private val ox=72f; private val oy=60f
    private val paint=Paint(1); private val label=Paint(1).apply{textAlign=Paint.Align.CENTER;typeface=Typeface.DEFAULT_BOLD}
    private val hexes=mutableListOf<Hx>();private val units=mutableListOf<Tok>(); private var selected:Tok?=null
    init{
        val ts=listOf(Terrain.PLAINS,Terrain.FOREST,Terrain.HILLS,Terrain.DESERT,Terrain.PLAINS,Terrain.SWAMP,Terrain.PLAINS,Terrain.MOUNTAINS,Terrain.TUNDRA)
        for(r in 0..6) for(q in 0..10) hexes+=Hx(q,r,ts[(q*2+r*5)%ts.size])
        units+=Tok(1,4,0,Kind.MELEE);units+=Tok(1,4,0,Kind.MELEE);units+=Tok(2,4,0,Kind.RANGED)
        units+=Tok(6,2,1,Kind.MELEE);units+=Tok(6,2,1,Kind.MELEE);units+=Tok(7,2,1,Kind.RANGED)
    }
    private fun center(h:Hx)=Pair(ox+R*sqrt(3f)*(h.q+h.r/2f),oy+R*1.5f*h.r)
    private fun path(x:Float,y:Float):Path{val p=Path();for(i in 0..5){val a=Math.toRadians((60*i-30).toDouble());val xx=x+R*cos(a).toFloat();val yy=y+R*sin(a).toFloat();if(i==0)p.moveTo(xx,yy)else p.lineTo(xx,yy)};p.close();return p}
    private fun dist(aq:Int,ar:Int,bq:Int,br:Int):Int{val ay=-aq-ar;val by=-bq-br;return maxOf(abs(aq-bq),abs(ay-by),abs(ar-br))}
    override fun onDraw(c:Canvas){
        c.drawColor(Color.rgb(55,45,35))
        for(h in hexes){val(x,y)=center(h);paint.style=Paint.Style.FILL;paint.color=h.terrain.color;c.drawPath(path(x,y),paint);paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=Color.rgb(60,50,40);c.drawPath(path(x,y),paint)}
        for(u in units){val h=hexes.first{it.q==u.q&&it.r==u.r};val(x0,y)=center(h);val same=units.filter{it.q==u.q&&it.r==u.r};val x=x0+(same.indexOf(u)-1)*18
            paint.style=Paint.Style.FILL;paint.color=if(u.player==0)Color.rgb(213,171,60) else Color.rgb(168,62,52);c.drawCircle(x,y,10f,paint)
            label.color=Color.WHITE;label.textSize=9f;c.drawText(if(u.kind==Kind.MELEE)"M" else "D",x,y+3,label)
            if(u===selected){paint.style=Paint.Style.STROKE;paint.strokeWidth=3f;paint.color=Color.WHITE;c.drawCircle(x,y,14f,paint)}
        }
    }
    override fun onTouchEvent(e:MotionEvent):Boolean{
        if(e.action!=MotionEvent.ACTION_UP)return true
        val h=hexes.minByOrNull{val(x,y)=center(it);(x-e.x)*(x-e.x)+(y-e.y)*(y-e.y)}?:return true
        val own=units.firstOrNull{it.q==h.q&&it.r==h.r&&it.player==0}
        if(selected==null&&own!=null){selected=own;invalidate();return true}
        val s=selected?:return true
        val enemies=units.filter{it.q==h.q&&it.r==h.r&&it.player!=0}
        if(enemies.isNotEmpty()){
            val range=if(s.kind==Kind.MELEE)1 else 2
            if(dist(s.q,s.r,h.q,h.r)<=range){
                val attackers=units.filter{it.player==0&&dist(it.q,it.r,h.q,h.r)<=(if(it.kind==Kind.MELEE)1 else 2)}
                val atk=attackers.size*2
                var def=enemies.sumOf{if(it.kind==Kind.MELEE)2 else 1}+h.terrain.def
                if(h.terrain==Terrain.SWAMP)def+=1
                val d=atk-def
                val loss=(if(d<=0)0 else if(d<=2)1 else if(d<=4)2 else 3).coerceAtMost(enemies.size)
                repeat(loss){units.remove(enemies[it])}
                selected=null;invalidate()
            }
            return true
        }
        if(dist(s.q,s.r,h.q,h.r)==1 && h.terrain.move<=3 && units.count{it.q==h.q&&it.r==h.r&&it.player==0}<3){
            s.q=h.q;s.r=h.r;selected=null;invalidate()
        }
        return true
    }
}
